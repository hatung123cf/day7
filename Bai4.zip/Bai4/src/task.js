class Task{
   constructor(title, priority, dueDate, completed) {
      this.title = title;
        this.priority = priority;
        this.dueDate = dueDate;
        this.completed = completed;
   }
}

export default Task;